const rows = document.querySelectorAll('.row');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
let isAnimating = false;

const slideWidth = document.querySelector('.slide').offsetWidth + 10; 

function smoothTransition(row, distance, duration, callback) {
  let start = null;
  const initialPosition = row.style.transform === '' ? 0 : parseInt(row.style.transform.replace('translateX(', '').replace('px)', '')) || 0;
  const targetPosition = initialPosition + distance;

  function animate(timestamp) {
    if (!start) start = timestamp;
    const progress = timestamp - start;
    const easing = easeInOutCubic(Math.min(progress / duration, 1)); 

    row.style.transform = `translateX(${initialPosition + easing * distance}px)`;

    if (progress < duration) {
      requestAnimationFrame(animate); 
    } else {
      row.style.transform = `translateX(${targetPosition}px)`;
      if (callback) callback(); 
    }
  }

  requestAnimationFrame(animate);
}

function easeInOutCubic(t) {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

function moveLeft() {
  if (!isAnimating) {
    isAnimating = true;
    rows.forEach(row => {
      smoothTransition(row, slideWidth, 700, () => { 
        row.prepend(row.lastElementChild);
        row.style.transition = 'none';
        row.style.transform = 'translateX(0)';
        isAnimating = false;
      });
    });
  }
}

function moveRight() {
  if (!isAnimating) {
    isAnimating = true;
    rows.forEach(row => {
      smoothTransition(row, -slideWidth, 700, () => {
        row.append(row.firstElementChild);
        row.style.transition = 'none';
        row.style.transform = 'translateX(0)';
        isAnimating = false;
      });
    });
  }
}

prevBtn.addEventListener('click', moveLeft);
nextBtn.addEventListener('click', moveRight);
